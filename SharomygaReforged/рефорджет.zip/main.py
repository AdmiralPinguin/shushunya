from core.data import load_data
from core.models import load_models
from core.predict import get_predictions

def main():
    df_up, df_down = load_data()
    nf_up, nf_down = load_models()
    preds = get_predictions(nf_up, nf_down, df_up, df_down)
    print(preds.tail(20))

if __name__ == "__main__":
    main()
